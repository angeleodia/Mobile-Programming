package com.example.projectakhir;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
//            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
//            return insets;
//        });
        getSupportActionBar().setTitle("Welcome, User");
        ActionBar actionBar;
        actionBar = getSupportActionBar();
        this.deleteDatabase("books.db");

        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#f5994e"));
        actionBar.setBackgroundDrawable(colorDrawable);

        findViewById(R.id.btnBookList).setOnClickListener(v ->
                startActivity(new Intent(this, booklist.class))
        );

        findViewById(R.id.btnAdd).setOnClickListener(v ->
                startActivity(new Intent(this, AddBook.class))
        );




    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate menu dari XML
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Tangani klik item menu
        int id = item.getItemId();
        if (id == R.id.action_about) {
            // Pindah ke AboutActivity
            Intent intent = new Intent(this, About.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}