package com.example.projectakhir;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class BookDetail extends AppCompatActivity {
    private TextView tvBookTitle, tvBookAuthor, tvBookDescription;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_book_detail);
        getSupportActionBar().hide();

//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
//            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
//            return insets;
//        });

        tvBookTitle =findViewById(R.id.tvBookTitle);
        tvBookAuthor = findViewById(R.id.tvBookAuthor);
        tvBookDescription = findViewById(R.id.tvBookDescription);

        Book book = (Book) getIntent().getSerializableExtra("BOOK");

        tvBookTitle.setText(book.title);
        tvBookAuthor.setText(book.author);
        tvBookDescription.setText(book.description);

//        ((TextView) findViewById(R.id.tvBookTitle)).setText(book.getTitle());
//        ((TextView) findViewById(R.id.tvBookAuthor)).setText(book.getAuthor());
//        ((TextView) findViewById(R.id.tvBookDescription)).setText(book.getDescription());

//        tvBookTitle = findViewById(R.id.tvBookTitle);
//        tvBookAuthor = findViewById(R.id.tvBookAuthor);
//        tvBookDescription = findViewById(R.id.tvBookDescription);
//
//        // Ambil data dari intent
//        String title = getIntent().getStringExtra("title");
//        String author = getIntent().getStringExtra("author");
//        String description = getIntent().getStringExtra("description");
//
//        // Set data ke TextView
//        tvBookTitle.setText(title);
//        tvBookAuthor.setText(author);
//        tvBookDescription.setText(description);
    }
}