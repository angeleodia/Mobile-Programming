package com.example.projectakhir;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class booklist extends AppCompatActivity {
    private RecyclerView recyclerView;
    private BookAdapter bookAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_booklist);
        getSupportActionBar().hide();
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
//            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
//            return insets;
//        });

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        BookDatabaseHelper db = new BookDatabaseHelper(this);
        List<Book> bookList = db.getAllBooks();

        if (bookList.isEmpty()) {
            db.addBook(new Book("Pride and Prejudice", "Jane Austen", "A romantic novel of manners."));
            db.addBook(new Book("The Great Gatsby", "F. Scott Fitzgerald", "A story about the American dream."));
            db.addBook(new Book("The Catcher in the Rye", "J.D.Salinger", "A classic novel originally published for adults."));
            db.addBook(new Book("To Kill a Mockingbird", "Harper Lee", "Pulitzer Prize-winning story of race and justice."));
            db.addBook(new Book("1984", "George Orwell", "A dystopian social science fiction novel."));

            bookList = db.getAllBooks();
        }

//        BookAdapter adapter = new BookAdapter(bookList);
//        recyclerView.setAdapter(adapter);

        bookAdapter = new BookAdapter(bookList, book -> {
            Intent intent = new Intent(this, BookDetail.class);
            intent.putExtra("BOOK", book);
            startActivity(intent);
        });

        recyclerView.setAdapter(bookAdapter);
    }
}